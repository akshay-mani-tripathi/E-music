EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'emusic_application@gmail.com'
EMAIL_HOST_PASSWORD = 'Password'
DEFAULT_FROM_EMAIL = EMAIL_HOST_USER
